import 'package:flutter/material.dart';
import 'package:marketi/Freatures/Auth/Sign_in_view.dart';
import 'package:marketi/Freatures/onboarding/on_boarding_view.dart';

class home_view extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SignInView(),
    );
  }
}